
import './App.css';
import Controller from './Controller'
function App() {
  return (
    <div className='App' >
      <Controller />
    </div>
  );
}

export default App;
